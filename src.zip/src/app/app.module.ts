import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MainpageComponent } from './mainpage/mainpage.component';
import { TimelineComponent } from './mainpage/timeline/timeline.component';
import { UploadpageComponent } from './mainpage/uploadpage/uploadpage.component';

import {MatToolbarModule} from '@angular/material/toolbar';
import {MatTabsModule} from '@angular/material/tabs';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { MatCardModule } from '@angular/material/card';
import {MatButtonModule} from '@angular/material/button'; 
import {MatDividerModule} from '@angular/material/divider';
import {MatIconModule} from '@angular/material/icon'; 
import {MatPaginatorModule} from '@angular/material/paginator';
import { WelcomeComponent } from './welcome/welcome.component'; 
import { DatahandlerService } from './datahandler.service';
import { NewpostComponent } from './mainpage/uploadpage/newpost/newpost.component';
import {MatInputModule} from '@angular/material/input'; 
import { FormsModule }   from '@angular/forms';


@NgModule({
  declarations: [
    AppComponent,
    MainpageComponent,
    TimelineComponent,
    UploadpageComponent,
    WelcomeComponent,
    NewpostComponent
  ],
  imports: [
    BrowserModule,    
    BrowserAnimationsModule,
    AppRoutingModule,
    MatToolbarModule,
    MatTabsModule,
    MatCardModule,
    MatButtonModule,
    MatDividerModule,
    MatIconModule,
    MatPaginatorModule,
    MatInputModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
