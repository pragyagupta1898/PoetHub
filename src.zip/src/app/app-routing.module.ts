import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainpageComponent } from './mainpage/mainpage.component';
import { TimelineComponent } from './mainpage/timeline/timeline.component';
import { UploadpageComponent } from './mainpage/uploadpage/uploadpage.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { NewpostComponent } from './mainpage/uploadpage/newpost/newpost.component';


const routes: Routes = [
  { path: 'mainpage', 
    component: MainpageComponent,
    children: [
      {
        path: 'timeline', // child route path
        component: TimelineComponent // child route component that the router renders
      },
      {
        path: 'uploadpage',
        component: UploadpageComponent, // another child route component that the router renders
        //children :[{path : 'newpost',component : NewpostComponent}]
      },
      {
        path: 'welcome',
        component: WelcomeComponent // another child route component that the router renders
      },
      {path : 'newpost',component : NewpostComponent}
  ] },
  { path: '',   redirectTo: '/mainpage/welcome', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
