import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';

@Component({
  selector: 'app-mainpage',
  templateUrl: './mainpage.component.html',
  styleUrls: ['./mainpage.component.css']
})
export class MainpageComponent implements OnInit {
  links = ['timeline', 'uploadpage', 'Third'];
  activeLink = this.links[0];
  background = '';
  navLinks = [
     {path : 'timeline', label: 'Timeline'},
     {path : 'uploadpage', label: 'Upload'}
   ];

  constructor(private router: Router) { }

  ngOnInit() {
  }
  public gotoHome()
  {
    this.router.navigate(['mainpage/welcome']);
  }
}
