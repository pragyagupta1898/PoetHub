import { Component, OnInit } from '@angular/core';
import Speech from 'speak-tts';
//import { Post } from '../../model/post.model';
import { structure } from '../../model/post.model';
import { DatahandlerService } from 'src/app/datahandler.service';

const speech = new Speech();

@Component({
  selector: 'app-timeline',
  templateUrl: './timeline.component.html',
  styleUrls: ['./timeline.component.css']
})
export class TimelineComponent implements OnInit {
//   index = 0;
//   length = 5;
//   isLiked = false;
//   isSpeaking = false;
//   posts : structure[] = [{
//     title : 'A tryst with Destiny',
//     text : 'Long years ago we made a tryst with destiny, \
//     and now the time comes when we shall redeem our pledge, \
//     not wholly or in full measure, but very substantially. \
//     At the stroke of the midnight hour, when the world sleeps,\
//      India will awake to life and freedom. A moment comes, \
//      which comes but rarely in history, \
//     when we step out from the old to new, when an age ends, \
//     and when the soul of a nation, \
//     long suppressed, finds utterance. \
//     The ambition of the greatest man of our generation \
//     has been to wipe every tear from every eye. \
//     That may be beyond us, but so long as there are tears and suffering, \
//     so long our work will not be over. And so we have to labour and to work,and work hard,\
//     to give reality to our dreams.\
//     Those dreams are for India, but they are also for the world.',
//     author : 'Jawahar Nehru',
//     img : 'nehru.jpg'
//   },
//   {
//     title : 'Preamble to the Constitution',
//     text : 'WE, THE PEOPLE OF INDIA, having solemnly resolved to constitute\
//      India into a SOVEREIGN SOCIALIST SECULAR DEMOCRATIC REPUBLIC and\
//       to secure to all its citizens JUSTICE, social, economic and political\
//     LIBERTY of thought, expression, belief, faith and worship\
//     EQUALITY of status and of opportunity;\
//     and to promote among them all\
//     FRATERNITY assuring the dignity of the individual and the unity and integrity of the Nation;\
//     In Our Constituent Assembly this twenty-sixth day of November, 1949,\
//      do Hereby Adopt, Enact And Give To Ourselves This Constitution.',
//     author : 'B R Ambedkar',
//     img : 'ambedkar.jpg'
//   },
//   {
//     title : 'I have a dream',
//     text : 'I have a dream that one day this nation will rise up and live out\
//      the true meaning of its creed : We hold these truths to be self-evident,\
//       that all men are created equal\
//     I have a dream that one day on the red hills of Georgia\
//      the sons of former slaves and the sons of former slave owners will be able\
//       to sit down together at the table of brotherhood.\
//     I have a dream that one day even the state of Mississippi,\
//      a state sweltering with the heat of injustice, sweltering with the heat of oppression, \
//      will be transformed into an oasis of freedom and justice.\
//      I have a dream that my four little children will one day live in a nation\
//       where they will not be judged by the color of their skin but by the content of \
//       their character. I have a dream today.\
//       I have a dream that one day down in Alabama, with its vicious racists, \
//       with its governor having his lips dripping with the words of “interposition” and “nullification”,\
//        one day right there in Alabama little black boys and \
//        black girls will be able to join hands with little white boys \
//        and white girls as sisters and brothers. I have a dream today.',
//     author : 'Martin Luther King Jr',
//     img : 'martin.jpg'
//   },
//   {
//     title : 'Quit India',
//     text : 'I believe that in the history of the world, there has not been a more \
//     genuinely democratic struggle for freedom than ours. I read Carlyle’s French \
//     Resolution while I was in prison, and Pandit Jawaharlal has told me something \
//     about the Russian revolution. But it is my conviction that inasmuch as these \
//     struggles were fought with the weapon of violence they failed to realize the \
//     democratic ideal. In the democracy which I have envisaged, a democracy established \
//     by non-violence, there will be equal freedom for all. Everybody will be his own master. \
//     It is to join a struggle for such democracy that I invite you today. Once you realize \
//     this you will forget the differences between the Hindus and Muslims, and think of yourselves \
//     as Indians only, engaged in the common struggle for independence.',
//     author : 'Mahatma Gandhi',
//     img : 'gandhi.jpg'
//   },
//   {
//     title : 'Speech of Alexander',
//     text : 'I could not have blamed you for being the first to lose heart if I, \
//     your commander, had not shared in your exhausting marches and your perilous \
//     campaigns; it would have been natural enough if you had done all the work merely \
//     for others to reap the reward. But it is not so. You and I, gentlemen, have shared \
//     the labour and shared the danger, and the rewards are for us all. The conquered \
//     territory belongs to you; from your ranks the governors of it are chosen; already \
//     the greater part of its treasure passes into your hands, and when all Asia is overrun, \
//     then indeed I will go further than the mere satisfaction of our ambitions: the utmost \
//     hopes of riches or power which each one of you cherishes will be far surpassed, and whoever\
//      wishes to return home will be allowed to go, either with me or without me. I will make \
//      those who stay the envy of those who return.',
//     author : 'Alexander the Great',
//     img : 'alexander.jpg'
//   }
// ];
  data : structure;
  isLiked : boolean;
  isRead : boolean;
  constructor(private handle:DatahandlerService) {
    speech.init().then((data) => {
	// The "data" object contains the list of available voices and the voice synthesis params
	  console.log("Speech is ready, voices are available", data)
      }).catch(e => {
	      console.error("An error occured while initializing : ", e)
      })

      speech.init({
        'volume': 1,
           'lang': 'en-GB',
           'rate': 1,
           'pitch': 1,
           'voice':'Microsoft David Desktop - English (United States)',
           'splitSentences': true,
           'listeners': {
               'onvoiceschanged': (voices) => {
                   console.log("Event voiceschanged", voices)
               }
           }
        })

   }
//Microsoft David Desktop - English (United States)
  ngOnInit() {
    this.data = this.handle.getPost();
    this.updateLiked();
  }

  public nextPage(){
    this.data = this.handle.nextPost();
    this.updateLiked();
  }

  public prevPage(){
    this.data = this.handle.prevPost();
    this.updateLiked();
  }

  public likePage(){
    this.handle.likePage();
    this.updateLiked();
  }

  public sharePage(){
   // this.data = this.handle.sharePost();
  }

  public readPage(){
    //this.data = this.handle.nextPost();
    this.handle.readPage();
    this.updateLiked();
  }

  public updateLiked(){
    this.isLiked = this.data.isLiked;
    this.isRead = this.data.isRead;
  }
}
