import { Component, OnInit } from '@angular/core';
import { structure } from '../../../model/post.model';
import { DatahandlerService } from 'src/app/datahandler.service';
import Speech from 'speak-tts';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';

const speech = new Speech();

@Component({
  selector: 'app-newpost',
  templateUrl: './newpost.component.html',
  styleUrls: ['./newpost.component.css']
})
export class NewpostComponent implements OnInit {

  data : structure;
  isLiked : boolean;
  isRead : boolean;
  constructor(private handle:DatahandlerService, private router: Router) {
    speech.init().then((data) => {
	// The "data" object contains the list of available voices and the voice synthesis params
	  console.log("Speech is ready, voices are available", data)
      }).catch(e => {
	      console.error("An error occured while initializing : ", e)
      })

      speech.init({
        'volume': 1,
           'lang': 'en-GB',
           'rate': 1,
           'pitch': 1,
           'voice':'Microsoft David Desktop - English (United States)',
           'splitSentences': true,
           'listeners': {
               'onvoiceschanged': (voices) => {
                   console.log("Event voiceschanged", voices)
               }
           }
        })

   }
//Microsoft David Desktop - English (United States)
  ngOnInit() {
    this.data = this.handle.getPost();
    this.updateLiked();
  }

  public nextPage(){
    this.data = this.handle.nextPost();
    this.updateLiked();
  }

  public backToPage(){
    this.router.navigate(['mainpage/uploadpage']);
  }

  public likePage(){
    this.handle.likePage();
    this.updateLiked();
  }

  public sharePage(){
   // this.data = this.handle.sharePost();
  }

  public readPage(){
    //this.data = this.handle.nextPost();
    this.handle.readPage();
    this.updateLiked();
  }

  public updateLiked(){
    this.isLiked = this.data.isLiked;
    this.isRead = this.data.isRead;
  }


}
