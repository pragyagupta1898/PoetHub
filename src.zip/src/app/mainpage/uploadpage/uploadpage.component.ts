import { Component, OnInit } from '@angular/core';
import { structure } from '../../model/post.model';
import { DatahandlerService } from 'src/app/datahandler.service';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';

@Component({
  selector: 'app-uploadpage',
  templateUrl: './uploadpage.component.html',
  styleUrls: ['./uploadpage.component.css']
})
export class UploadpageComponent implements OnInit {
  posttitle = '';
  postimg = '';
  postauthor='';
  posttxt='';
  postlike=false;
  postread=false;
  data: structure = {
    title : '',
    author:'',
    text:'',
    img:'',
    isLiked:false,
    isRead : false
  };
  constructor(private router: Router, private handle: DatahandlerService) {
   }

  ngOnInit() {
  }
  public addPost(){
    this.data.title = this.posttitle;
    this.data.author = this.postimg;
    this.data.text = this.posttxt;
    this.data.img = this.postimg;
    this.data.isLiked = this.postlike;
    this.data.isRead = this.postread;
    //console.log(this.data);
    this.handle.addPost(this.data);
    this.router.navigate(['mainpage/newpost']);
  }
}
