import { Injectable } from '@angular/core';
import { Post, structure } from './model/post.model';
import Speech from 'speak-tts';

const speech = new Speech();

@Injectable({
  providedIn: 'root'
})
export class DatahandlerService {

  constructor() {
    speech.init().then((data) => {
      // The "data" object contains the list of available voices and the voice synthesis params
        console.log("Speech is ready, voices are available", data)
          }).catch(e => {
            console.error("An error occured while initializing : ", e)
          })
    
          speech.init({
            'volume': 1,
               'lang': 'en-GB',
               'rate': 0.85,
               'pitch': 1,
               'voice':'Microsoft Zira Desktop - English (United States)',
               'splitSentences': true,
               'listeners': {
                   'onvoiceschanged': (voices) => {
                       console.log("Event voiceschanged", voices)
                   }
               }
            })
   }

  public nextPost(){
    //Post.posts[Post.index].isRead = false;
    console.log('next');
    if(Post.index!=Post.size-1)
      Post.index = Post.index + 1;
    else
      Post.index = 0;
    return this.getPost();
  }

  public prevPost(){
    //Post.posts[Post.index].isRead = false;
    console.log('prev');
    if(Post.index!=0)
      Post.index = Post.index - 1;
    else
      Post.index = Post.size - 1;
    return this.getPost();
  }

  public getPost(){
    return Post.posts[Post.index];
  }

  public likePage(){
    console.log('like');
    Post.posts[Post.index].isLiked = !Post.posts[Post.index].isLiked;
  }

  public readPage(){
    if(Post.posts[Post.index].isRead == false){
      Post.posts[Post.index].isRead = true;
    speech.speak({
      text: Post.posts[Post.index].text,
        }).then(() => {
      console.log("Success !")
        }).catch(e => {
      console.error("An error occurred :", e)
  })
  }
    else{
      speech.cancel();
      Post.posts[Post.index].isRead = false;
    }
  }

  public addPost(data : structure){
    //console.log(data);
    Post.posts.unshift(data);
  }
}
